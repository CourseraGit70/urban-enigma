### OS / Environment
<!--- where do you run Algo? -->


### Ansible version
<!--- `ansible --version` -->


### Version of components from `requirements.txt`
<!--- 
pip show <package> (all the packages from requirements.txt)
PUT THE OUTPUT HERE. DON'T NEED TO PASTE requirements.txt
-->


### Summary of the problem



### Steps to reproduce the behavior



### The way of deployment (cloud or local)



### Expected behavior



### Actual behavior



### Full log
<!--- Put here the FULL LOG after you run the ./algo script -->

